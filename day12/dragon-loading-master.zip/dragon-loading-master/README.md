# Dragon Loading

A loading animation made with CSS.

![dragon loading gif](https://cdn.dribbble.com/users/351764/screenshots/4003643/dragon-loading.gif)

- [HTML demo](https://devyumao.github.io/dragon-loading/)

- [GIF demo](https://dribbble.com/shots/4003643-Dragon-Loading)
